package com.example.animalcompanymenu

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 18, 25)
    private val panel = Color.rgb(28, 33, 44)
    private val accent = Color.rgb(110, 231, 183)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(bg)
            setPadding(24, 20, 24, 20)
        }
        val sidebar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(panel)
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 18, 18, 18)
        }
        root.addView(sidebar, LinearLayout.LayoutParams(210, -1))
        root.addView(content, LinearLayout.LayoutParams(0, -1, 1f))

        val title = TextView(this).apply {
            text = "ANIMAL COMPANY"
            textSize = 21f
            setTextColor(accent)
            setPadding(0, 0, 0, 28)
        }
        sidebar.addView(title)
        val heading = TextView(this).apply {
            text = "PRIVATE MENU"
            textSize = 25f
            setTextColor(Color.WHITE)
            setPadding(0, 4, 0, 18)
        }
        content.addView(heading)

        val status = TextView(this).apply {
            text = "Standalone interface prototype • Not connected to the game"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, 22)
        }
        content.addView(status)

        fun section(name: String, items: List<String>) {
            val button = Button(this).apply {
                text = name
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(panel)
            }
            sidebar.addView(button, LinearLayout.LayoutParams(-1, 52).apply { bottomMargin = 8 })
            button.setOnClickListener {
                content.removeViews(2, content.childCount - 2)
                val sub = TextView(this).apply {
                    text = name.uppercase()
                    textSize = 20f
                    setTextColor(accent)
                    setPadding(0, 0, 0, 16)
                }
                content.addView(sub)
                items.forEach { item ->
                    val toggle = Switch(this).apply {
                        text = item
                        textSize = 17f
                        setTextColor(Color.WHITE)
                        buttonTintList = null
                        setPadding(8, 10, 8, 10)
                    }
                    content.addView(toggle, LinearLayout.LayoutParams(-1, 58))
                }
            }
        }
        section("Home", listOf("Show menu hints", "Remember last tab"))
        section("Movement", listOf("Movement demo toggle", "Comfort mode"))
        section("Visuals", listOf("High contrast UI", "Show status labels"))
        section("Settings", listOf("Large text", "Left-hand layout"))

        val note = TextView(this).apply {
            text = "These switches only change this demo interface. They do not modify Animal Company or affect other players."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 24, 0, 0)
        }
        content.addView(note)
        setContentView(root)
    }
}
